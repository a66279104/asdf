#!/bin/bash
mkdir -p syn
design_vision -no_gui -f non_secret_test.dcsh
