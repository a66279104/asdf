#!/bin/bash
mkdir -p syn
design_vision -no_gui -f sha3.dcsh
