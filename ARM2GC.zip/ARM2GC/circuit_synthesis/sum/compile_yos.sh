#!/bin/bash
mkdir -p syn_yos
~/yosys/yosys -s sum.yos
