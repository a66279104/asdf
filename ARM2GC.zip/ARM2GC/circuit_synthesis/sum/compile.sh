#!/bin/bash
mkdir -p syn
design_vision -no_gui -f sum.dcsh
