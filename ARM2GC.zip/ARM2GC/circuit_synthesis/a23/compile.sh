#!/bin/bash
mkdir -p syn
make