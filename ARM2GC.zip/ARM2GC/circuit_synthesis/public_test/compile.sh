#!/bin/bash
mkdir -p syn
design_vision -no_gui -f public_test.dcsh
