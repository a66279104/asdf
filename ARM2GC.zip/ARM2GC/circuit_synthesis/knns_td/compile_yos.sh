#!/bin/bash
mkdir -p syn_yos
yosys -s knns_td.yos
