#!/bin/bash
mkdir -p syn
dc_shell-t -no_gui -f encoder.dcsh
