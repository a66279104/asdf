#!/bin/bash

design_vision -no_gui -f sample.dcsh
