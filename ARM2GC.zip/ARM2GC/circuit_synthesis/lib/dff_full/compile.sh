#!/bin/sh
lc_shell -f compile.dcsh